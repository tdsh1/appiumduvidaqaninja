def hello_robot(nome):
    return "Olá, " + nome +"."


    