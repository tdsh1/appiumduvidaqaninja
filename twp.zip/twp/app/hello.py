def hello_robot():
    return "Olá, bem vindo ao curso de Robot Mobile."
    
    resultado = hello_robot()
    print(resultado)